package spring.com.demo.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@Entity
@Table(name = "persons")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long  ID;

    @Column(name = "name")
    private String name;

    @Column(name = "type")
    private UserType type;

    @Column(name = "password")
    private String password;

    @Column(name = "DOB")
    private String DOB;

    @ManyToMany
    private Set<Course> courses = new HashSet<>();


    public User(String name, UserType userType, String password, String dob) {
        this.name =  name;
        this.type = userType;
        this.password = password;
        this.DOB = dob;
    }
    public User(){

    }





    /*@OneToMany(targetEntity=Course.class, mappedBy="Coach",cascade=CascadeType.DETACH, fetch = FetchType.LAZY)
    private Set<Course> CourseManagedByCoach;*/

   /* @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "courseId")
    private Course course_prof;*/
}



