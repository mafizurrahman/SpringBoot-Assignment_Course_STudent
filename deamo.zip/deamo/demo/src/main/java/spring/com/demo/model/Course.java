package spring.com.demo.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Data
@Entity
@Table(name = "courses")
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long courseId;

    @Column(name = "name")
    private String name;

    @Column(name = "start")
    private String start;

    @Column(name = "end")
    private String end;

    @Column(name = "semester")
    private String semester;



    @ManyToMany(fetch = FetchType.LAZY,
            cascade = {
                    CascadeType.PERSIST,
                    CascadeType.MERGE
            })
    @JoinTable(name = "user_course",
            joinColumns = { @JoinColumn(name = "courseId") },
            inverseJoinColumns = { @JoinColumn(name = "id") })
    @JsonIdentityInfo(
            generator = ObjectIdGenerators.PropertyGenerator.class,property = "id" )
    @JsonIdentityReference(alwaysAsId = true)
    private Set<User> users = new HashSet<>();



    public Course(String name, String start, String end, String semester) {
        this.name =  name;
        this.start = start;
        this.end = end;
        this.semester = semester;
    }
    public Course(){
}
@Override
public String toString(){
        return this.name;
}




   /* @ManyToOne
    @JoinTable(name = "user_course", joinColumns = { @JoinColumn(name = "courseId", nullable = false, updatable = false) }, inverseJoinColumns = { @JoinColumn(name = "id",
            nullable = false, updatable = false) })
    private Course Coach;

    @OneToOne(mappedBy = "course_prof")
    private User user;*/
}
