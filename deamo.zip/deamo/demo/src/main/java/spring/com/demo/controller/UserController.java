package spring.com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import spring.com.demo.model.Course;
import spring.com.demo.model.User;
import spring.com.demo.model.UserType;
import spring.com.demo.repository.UserRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "user")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public ResponseEntity populateUser(){
        populate();
        return new ResponseEntity(HttpStatus.OK);
    }


    public void populate()
    {
        User user = new User("Marjan", UserType.STUDENT,  "1234","01-01-1999");
        userRepository.save(user);

    }

    @DeleteMapping("/{userId}")
    public void deleteUser(@PathVariable Long userId)
    {
        userRepository.deleteById(userId);
    }


    //creating post mapping that post the book detail in the database
    @PostMapping("/userSave")
    @ResponseStatus(HttpStatus.CREATED)
    public User saveUser(@RequestBody User user)
    {
        System.out.println("here");
        for(Course c:user.getCourses()){
            System.out.println(c.toString());
        }

        return userRepository.save(user);
    }





    @RequestMapping(value = "/{userId}",  method = RequestMethod.GET)
    public User getUser(@PathVariable Long userId)
    {
        Optional<User> optionalUser = userRepository.findById(userId);
        if(optionalUser.isPresent())
        {
            return optionalUser.get();
        }
        return null;
    }

    @RequestMapping(value = "/getAllUser",  method = RequestMethod.GET)
    public List<User> getAllUser()
    {
        List<User> userList = userRepository.findAll();
        return userList;
    }
}


