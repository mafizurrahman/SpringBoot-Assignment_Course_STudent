package spring.com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import spring.com.demo.model.Course;
import spring.com.demo.model.User;
import spring.com.demo.model.UserType;
import spring.com.demo.repository.CourseRepository;
import spring.com.demo.repository.UserRepository;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping(value = "course")
public class CourseController {

    @Autowired
    private CourseRepository courseRepository;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public ResponseEntity populateCourse(){
        populate();
        return new ResponseEntity(HttpStatus.OK);
    }


    public void populate()
    {
        Course course = new Course("Algorithm", "03 april",  "02 june","FAll22");
        courseRepository.save(course);

    }

    @DeleteMapping("/{courseId}")
    private void deleteCourse(@PathVariable Long courseId)
    {
        courseRepository.deleteById(courseId);
    }


    //creating post mapping that post the book detail in the database
    @PostMapping("/courseSave")
    @ResponseStatus(HttpStatus.CREATED)
    private Course saveCourse(@RequestBody Course course)
    {
        return courseRepository.save(course);
    }



    @RequestMapping(value = "/{courseId}",  method = RequestMethod.GET)
    public Course getCourse(@PathVariable Long courseId)
    {
        Optional<Course> optionalCourse = courseRepository.findById(courseId);
        if(optionalCourse.isPresent())
        {
            return optionalCourse.get();
        }
        return null;
    }

    @RequestMapping(value = "/getAllCourse",  method = RequestMethod.GET)
    public List<Course> getAllUser()
    {
        List<Course> courseList = courseRepository.findAll();
        return courseList;
    }
}