package spring.com.demo.model;

public enum UserType {

    ADMIN,
    STUDENT,
    PROFESSOR
}
