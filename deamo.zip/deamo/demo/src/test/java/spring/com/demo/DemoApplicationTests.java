package spring.com.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import spring.com.demo.controller.UserController;
import spring.com.demo.model.User;
import spring.com.demo.model.UserType;
import spring.com.demo.repository.UserRepository;

import javax.annotation.Resource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static net.bytebuddy.matcher.ElementMatchers.is;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class DemoApplicationTests {

//	User user = new User("Marjan", UserType.STUDENT,  "1234","01-01-1999");
	@MockBean
	private UserController userController;
	@Test
	public void testGetAllUser() throws Exception {
		User user = new User("Marjan", UserType.STUDENT,  "1234","01-01-1999");
		List<User> userList = new ArrayList<>();
		userList.add(user);
		given(userController.getAllUser()).willReturn(userList);
		List<User> result = userController.getAllUser();
		assertEquals(result.size(), 1);
		System.out.println(result.get(0).getName());
	}

	@Test
	public void testDeleteEmployee() throws Exception {
		doNothing().when(userController).deleteUser(1L);
		userController.deleteUser(1L);
		assertTrue(true);
	}


}
